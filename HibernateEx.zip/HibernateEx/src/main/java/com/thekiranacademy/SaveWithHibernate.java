package com.thekiranacademy;



import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class SaveWithHibernate {

	public static void main(String[] args) {

		Session session=new Configuration().configure().addAnnotatedClass(Employee.class).buildSessionFactory().openSession();
		
		Employee employee=new Employee();
		employee.setEid(501);
		employee.setName("sachin");
		employee.setSalary(100000);
		
		Transaction tx=session.beginTransaction();
		
			session.save(employee);
		
		tx.commit();
		
		System.out.println("Done");
	
	}

}
